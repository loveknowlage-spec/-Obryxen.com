
import React from 'react';

const Notifications: React.FC = () => {
  const notices = [
    { id: 1, type: 'like', user: 'Camila', avatar: 'https://picsum.photos/seed/n1/60/60', time: '2m', post: 'https://picsum.photos/seed/np1/100/100' },
    { id: 2, type: 'follow', user: 'Mark_Z', avatar: 'https://picsum.photos/seed/n2/60/60', time: '1h', status: 'Followed you' },
    { id: 3, type: 'comment', user: 'Jackson', avatar: 'https://picsum.photos/seed/n3/60/60', time: '3h', post: 'https://picsum.photos/seed/np2/100/100', text: 'Stunning!' },
    { id: 4, type: 'mention', user: 'Studio_9', avatar: 'https://picsum.photos/seed/n4/60/60', time: '5h', post: 'https://picsum.photos/seed/np3/100/100' },
  ];

  return (
    <div className="px-6 py-4 space-y-8 pb-32">
      <h2 className="text-2xl font-bold">Activity</h2>

      <div className="space-y-6">
         <section>
           <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-4">New</h3>
           <div className="space-y-6">
              {notices.slice(0, 1).map(item => <NotificationItem key={item.id} {...item} />)}
           </div>
         </section>

         <section>
           <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-4">Earlier</h3>
           <div className="space-y-6">
              {notices.slice(1).map(item => <NotificationItem key={item.id} {...item} />)}
           </div>
         </section>
      </div>
    </div>
  );
};

const NotificationItem: React.FC<any> = ({ user, avatar, time, type, post, text, status }) => (
  <div className="flex items-center gap-4 group">
    <img src={avatar} className="w-12 h-12 rounded-2xl object-cover" />
    <div className="flex-1 text-sm">
       <p className="text-zinc-300">
         <span className="font-bold text-white">{user}</span> {type === 'like' ? 'liked your post.' : type === 'follow' ? 'started following you.' : type === 'comment' ? `commented: "${text}"` : 'mentioned you in a post.'}
         <span className="text-zinc-600 ml-2">{time}</span>
       </p>
    </div>
    {post ? (
      <img src={post} className="w-10 h-10 rounded-lg object-cover" />
    ) : (
      <button className="px-4 py-1.5 bg-amber-500 text-zinc-950 text-[10px] font-bold rounded-lg">Follow</button>
    )}
  </div>
);

export default Notifications;
