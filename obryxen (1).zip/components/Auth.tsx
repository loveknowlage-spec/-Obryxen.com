
import React, { useState } from 'react';
import { auth } from '../firebase';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';
import { Mail, Lock, User, ArrowRight, Github, Chrome } from 'lucide-react';

const ObryxenLogo = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 100 60" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="logoGradientAuth" x1="0%" y1="50%" x2="100%" y2="50%">
        <stop offset="0%" stopColor="#3b82f6" />
        <stop offset="50%" stopColor="#60a5fa" />
        <stop offset="100%" stopColor="#93c5fd" />
      </linearGradient>
      <filter id="glow">
        <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
        <feMerge>
            <feMergeNode in="coloredBlur"/>
            <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>
    <path 
      d="M35 15C25 15 15 22 15 30C15 38 25 45 35 45C42 45 48 40 52 35L58 25C62 20 68 15 75 15C85 15 95 22 95 30C95 38 85 45 75 45C68 45 62 40 58 35L52 25C48 20 42 15 35 15Z" 
      stroke="url(#logoGradientAuth)" 
      strokeWidth="10" 
      strokeLinecap="round"
      filter="url(#glow)"
    />
  </svg>
);

interface AuthProps {
  onSuccess: () => void;
}

const Auth: React.FC<AuthProps> = ({ onSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        await updateProfile(userCredential.user, { 
          displayName: username,
          photoURL: `https://i.pravatar.cc/150?u=${userCredential.user.uid}`
        });
      }
      onSuccess();
    } catch (err: any) {
      setError(err.message.replace('Firebase:', '').trim());
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex flex-col items-center justify-center px-6 relative overflow-hidden">
      {/* Dynamic Background Atmosphere */}
      <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] bg-blue-600/15 blur-[140px] rounded-full animate-pulse"></div>
      <div className="absolute bottom-[-10%] left-[-5%] w-[500px] h-[500px] bg-blue-900/10 blur-[120px] rounded-full"></div>
      
      <div className="w-full max-w-md relative z-10 space-y-10">
        <div className="text-center space-y-6">
          <div className="flex justify-center">
             <div className="w-28 h-28 relative flex items-center justify-center">
                 <div className="absolute inset-0 bg-blue-500/20 rounded-full blur-[40px] scale-150"></div>
                 <ObryxenLogo className="w-full h-full relative z-10" />
             </div>
          </div>
          <div className="space-y-2">
            <h1 className="text-5xl font-black italic tracking-tighter text-white drop-shadow-2xl">
              Obryxen
            </h1>
            <p className="text-zinc-500 text-sm font-bold uppercase tracking-[0.2em]">
              {isLogin ? 'Premium Access' : 'Create Identity'}
            </p>
          </div>
        </div>

        <div className="glass-card rounded-[3rem] p-8 border border-white/10 shadow-2xl relative overflow-hidden">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-4">
              {!isLogin && (
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-6 flex items-center pointer-events-none">
                    <User size={18} className="text-zinc-600 group-focus-within:text-blue-400 transition-colors" />
                  </div>
                  <input
                    type="text"
                    required
                    placeholder="Full Name"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="block w-full pl-16 pr-6 py-5 bg-white/5 border border-white/5 rounded-2xl focus:ring-2 focus:ring-blue-500/20 outline-none transition-all placeholder:text-zinc-700 text-sm text-white font-medium"
                  />
                </div>
              )}

              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-6 flex items-center pointer-events-none">
                  <Mail size={18} className="text-zinc-600 group-focus-within:text-blue-400 transition-colors" />
                </div>
                <input
                  type="email"
                  required
                  placeholder="Email Address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="block w-full pl-16 pr-6 py-5 bg-white/5 border border-white/5 rounded-2xl focus:ring-2 focus:ring-blue-500/20 outline-none transition-all placeholder:text-zinc-700 text-sm text-white font-medium"
                />
              </div>

              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-6 flex items-center pointer-events-none">
                  <Lock size={18} className="text-zinc-600 group-focus-within:text-blue-400 transition-colors" />
                </div>
                <input
                  type="password"
                  required
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full pl-16 pr-6 py-5 bg-white/5 border border-white/5 rounded-2xl focus:ring-2 focus:ring-blue-500/20 outline-none transition-all placeholder:text-zinc-700 text-sm text-white font-medium"
                />
              </div>
            </div>

            {error && (
              <div className="bg-rose-500/10 border border-rose-500/20 rounded-2xl p-4 animate-in fade-in">
                <p className="text-rose-400 text-xs font-bold text-center uppercase tracking-widest">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-5 bg-white text-black rounded-2xl font-black text-sm shadow-[0_20px_40px_rgba(255,255,255,0.1)] flex items-center justify-center gap-3 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50"
            >
              {loading ? (
                <div className="w-5 h-5 border-[3px] border-black/20 border-t-black rounded-full animate-spin"></div>
              ) : (
                <>
                  <span className="uppercase tracking-widest">{isLogin ? 'Authenticate' : 'Establish Identity'}</span>
                  <ArrowRight size={20} strokeWidth={3} />
                </>
              )}
            </button>
          </form>

          <div className="mt-8 pt-8 border-t border-white/5 space-y-6">
            <div className="flex items-center gap-4 py-2">
              <div className="h-px flex-1 bg-white/5"></div>
              <span className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-600">Secure Vault</span>
              <div className="h-px flex-1 bg-white/5"></div>
            </div>

            <div className="grid grid-cols-2 gap-4">
               <button className="py-4 bg-white/5 rounded-2xl text-white font-bold text-xs flex items-center justify-center gap-3 hover:bg-white/10 transition-all border border-white/5">
                 <Github size={18} />
                 GitHub
               </button>
               <button className="py-4 bg-white/5 rounded-2xl text-white font-bold text-xs flex items-center justify-center gap-3 hover:bg-white/10 transition-all border border-white/5">
                 <Chrome size={18} />
                 Google
               </button>
            </div>
          </div>
        </div>

        <button
          onClick={() => setIsLogin(!isLogin)}
          className="w-full py-4 text-sm font-black text-zinc-500 hover:text-blue-400 transition-all uppercase tracking-widest text-center"
        >
          {isLogin ? "No access key? Create one now" : "Existing entity? Enter terminal"}
        </button>
      </div>
    </div>
  );
};

export default Auth;
