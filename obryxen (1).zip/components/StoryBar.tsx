
import React from 'react';

const StoryBar: React.FC = () => {
  const stories = [
    { id: '1', name: 'My Story', img: 'https://picsum.photos/seed/self/100/100', isMe: true },
    { id: '2', name: 'Camelia', img: 'https://picsum.photos/seed/p1/100/100', isViewed: false },
    { id: '3', name: 'Kim_00', img: 'https://picsum.photos/seed/p2/100/100', isViewed: false },
    { id: '4', name: 'Angelia_', img: 'https://picsum.photos/seed/p3/100/100', isViewed: true },
    { id: '5', name: 'Jackson', img: 'https://picsum.photos/seed/p4/100/100', isViewed: true },
    { id: '6', name: 'Sarah', img: 'https://picsum.photos/seed/p5/100/100', isViewed: true },
  ];

  return (
    <div className="flex items-center gap-5 px-6 py-4 overflow-x-auto no-scrollbar">
      {stories.map((story) => (
        <div key={story.id} className="flex flex-col items-center gap-2 flex-shrink-0 cursor-pointer group">
          <div className={`relative p-0.5 rounded-full ${story.isMe ? '' : story.isViewed ? 'bg-obryxen-dark/40' : 'bg-gradient-to-tr from-obryxen-medium via-obryxen-light to-obryxen-pale'}`}>
            <div className="relative w-16 h-16 rounded-full border-2 border-obryxen-deep overflow-hidden bg-obryxen-dark">
              <img src={story.img} alt={story.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
              {story.isMe && (
                <div className="absolute bottom-0 right-0 bg-obryxen-pale rounded-full p-0.5 border-2 border-obryxen-deep">
                  <svg className="w-4 h-4 text-obryxen-deep" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
            </div>
          </div>
          <span className={`text-[11px] font-medium truncate w-16 text-center ${story.isMe ? 'text-obryxen-light' : 'text-obryxen-pale/60 group-hover:text-obryxen-pale'}`}>
            {story.name}
          </span>
        </div>
      ))}
    </div>
  );
};

export default StoryBar;
