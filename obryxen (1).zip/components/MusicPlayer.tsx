
import React, { useState } from 'react';
import { 
  Play, 
  SkipBack, 
  SkipForward, 
  Heart, 
  Shuffle, 
  ChevronDown, 
  MoreHorizontal, 
  Repeat,
  Pause
} from 'lucide-react';

const MusicPlayer: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const playlists = [
    { id: 1, title: 'Mad love', artist: 'Mabel', img: 'https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=200&h=200&fit=crop', active: true },
    { id: 2, title: 'Sweetener', artist: 'Ariana Grande', img: 'https://images.unsplash.com/photo-1514525253344-f814d0743b1c?w=200&h=200&fit=crop' },
    { id: 3, title: 'Solastalgia', artist: 'Missy Higgins', img: 'https://images.unsplash.com/photo-1493225255756-d9584f8606e9?w=200&h=200&fit=crop' },
    { id: 4, title: 'Youngblood', artist: '5 Seconds of Summer', img: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=200&h=200&fit=crop' },
    { id: 5, title: 'Golden Hour', artist: 'Kacey Musgraves', img: 'https://images.unsplash.com/photo-1459749411177-042180ce673c?w=200&h=200&fit=crop' },
  ];

  return (
    <div className="px-5 py-4 space-y-8 pb-40 min-h-screen bg-black overflow-y-auto no-scrollbar">
      {/* 1. Albums Widget (Top Left in Image) */}
      <section className="glass-card rounded-[2.5rem] p-6 border border-white/10 shadow-2xl relative overflow-hidden group">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-medium text-white/90">Albums</h2>
          <span className="text-[10px] text-white/30 font-bold tracking-widest">4/67</span>
        </div>

        <div className="relative aspect-square rounded-[2rem] overflow-hidden shadow-2xl mb-8">
          <img 
            src="https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=600&h=600&fit=crop" 
            alt="Current Album" 
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
          <div className="absolute bottom-6 left-6">
            <h3 className="text-xl font-bold text-white">Mad Love</h3>
            <p className="text-white/40 text-[11px] font-medium mt-0.5">12 songs in album</p>
          </div>
        </div>

        <div className="space-y-4">
          {playlists.slice(2, 5).map((song) => (
            <div key={song.id} className="flex items-center gap-4 group cursor-pointer hover:bg-white/5 p-2 -mx-2 rounded-2xl transition-all">
              <img src={song.img} className="w-10 h-10 rounded-xl object-cover shadow-lg border border-white/5" />
              <div className="flex-1">
                <h4 className="text-xs font-bold text-white/80">{song.title}</h4>
                <p className="text-[10px] text-white/30 font-medium">{song.artist}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 2. Main High-Fidelity Player (Middle in Image) */}
      <section className="glass-card rounded-[3.5rem] p-0 border border-white/10 shadow-2xl relative overflow-hidden flex flex-col items-center">
        {/* Large Portrait Cover Art */}
        <div className="w-full aspect-[3/4.2] relative overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=800&h=1200&fit=crop" 
            className="w-full h-full object-cover" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/10 to-transparent"></div>
          
          {/* Controls Overlayed on Bottom of Image */}
          <div className="absolute bottom-10 left-0 right-0 px-10 text-center space-y-8">
            <div>
              <h3 className="text-3xl font-bold tracking-tight text-white mb-1">Mad love</h3>
              <p className="text-white/40 text-sm font-medium">Mabel</p>
            </div>

            {/* Premium Glass Progress Bar */}
            <div className="space-y-3">
              <div className="h-0.5 w-full bg-white/10 rounded-full relative">
                <div className="h-full bg-rose-400/80 w-[42%] rounded-full shadow-[0_0_15px_rgba(251,113,133,0.4)]"></div>
                <div className="absolute top-1/2 left-[42%] -translate-y-1/2 -translate-x-1/2 w-2.5 h-2.5 bg-rose-400 rounded-full shadow-[0_0_10px_rgba(251,113,133,0.8)] border-2 border-white/10"></div>
              </div>
            </div>

            {/* Main Playback Controls */}
            <div className="flex items-center justify-between">
              <button className="text-white/20 hover:text-white transition-colors"><Repeat size={16} /></button>
              <div className="flex items-center gap-8">
                <button className="text-white/80 hover:text-white active:scale-90 transition-all"><SkipBack size={24} fill="currentColor" /></button>
                <button 
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-black shadow-[0_0_30px_rgba(255,255,255,0.2)] active:scale-95 transition-all"
                >
                  {isPlaying ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" className="ml-1" />}
                </button>
                <button className="text-white/80 hover:text-white active:scale-90 transition-all"><SkipForward size={24} fill="currentColor" /></button>
              </div>
              <button className="text-white/20 hover:text-white transition-colors"><Heart size={16} /></button>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Playlist Widget (Right in Image) */}
      <section className="glass-card rounded-[2.5rem] p-8 border border-white/10 shadow-2xl space-y-8">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-medium text-white/90">Playlist (56)</h3>
          <button className="p-2 hover:bg-white/5 rounded-full transition-colors"><ChevronDown size={20} className="text-white/30" /></button>
        </div>
        
        <div className="space-y-6">
          {playlists.map((song) => (
            <div key={song.id} className="flex items-center gap-4 group cursor-pointer">
              <div className="relative">
                <img src={song.img} className="w-14 h-14 rounded-2xl object-cover shadow-xl border border-white/10" />
                {song.active && (
                  <div className="absolute inset-0 bg-black/40 rounded-2xl flex items-center justify-center">
                    <Pause size={18} fill="white" className="text-white" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-sm text-white/90">{song.title}</h4>
                <p className="text-[11px] text-white/30 font-medium">{song.artist}</p>
              </div>
              <div className="flex items-center gap-4">
                <button className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${song.active ? 'bg-rose-500/10 text-rose-500' : 'text-white/20 hover:text-white/60'}`}>
                  <Play size={14} fill="currentColor" className={song.active ? '' : 'ml-0.5'} />
                </button>
                <button className="text-white/10 hover:text-white/40 transition-colors">
                  <SkipForward size={14} fill="currentColor" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Mini Global Player (Matching the Bottom Row in Image) */}
      <div className="fixed bottom-32 left-1/2 -translate-x-1/2 w-[90%] max-w-sm z-40 px-4">
        <div className="glass-nav rounded-3xl p-3 border border-white/10 flex items-center gap-4 shadow-2xl">
           <img src={playlists[0].img} className="w-10 h-10 rounded-xl object-cover" />
           <div className="flex-1">
              <p className="text-xs font-bold text-white">Mad love</p>
              <p className="text-[10px] text-white/40 font-medium">Mabel</p>
           </div>
           <div className="flex items-center gap-4 pr-2">
              <button 
                onClick={() => setIsPlaying(!isPlaying)}
                className="p-2 bg-rose-500 rounded-full text-white shadow-lg shadow-rose-500/20"
              >
                {isPlaying ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" className="ml-0.5" />}
              </button>
              <button className="text-white/20"><SkipForward size={16} fill="currentColor" /></button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default MusicPlayer;
