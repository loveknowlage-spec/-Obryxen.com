
import React, { useState, useRef, useEffect } from 'react';
import { 
  ChevronLeft, 
  MoreHorizontal, 
  Camera, 
  Mic, 
  Image as ImageIcon, 
  Send, 
  Search, 
  Plus, 
  Phone, 
  Info,
  ArrowLeft
} from 'lucide-react';
import { getChatResponse } from '../services/gemini';

interface MessagesProps {
  onBack: () => void;
}

interface Message {
  id: string;
  text: string;
  time: string;
  isSender: boolean;
}

const Messages: React.FC<MessagesProps> = ({ onBack }) => {
  const [selectedChat, setSelectedChat] = useState<any>(null);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  useEffect(() => {
    if (selectedChat) {
      // Load initial mock messages
      setMessages([
        { id: '1', text: "It's called Winds of Tomorrow", time: "10:09 PM", isSender: false },
        { id: '2', text: "It's so good! 🤩 The story is super engaging, and the characters are so well-written.", time: "10:09 PM", isSender: false },
      ]);
    }
  }, [selectedChat]);

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      text: inputText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isSender: true,
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    // Call Gemini for response
    const aiResponseText = await getChatResponse([], inputText);
    
    setIsTyping(false);
    const aiMsg: Message = {
      id: (Date.now() + 1).toString(),
      text: aiResponseText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isSender: false,
    };
    setMessages(prev => [...prev, aiMsg]);
  };

  const contacts = [
    { id: 'add', name: 'Add', avatar: '', isAdd: true },
    { id: '1', name: 'Adison', avatar: 'https://i.pravatar.cc/150?u=adison' },
    { id: '2', name: 'Charlie', avatar: 'https://i.pravatar.cc/150?u=charlie' },
    { id: '3', name: 'James', avatar: 'https://i.pravatar.cc/150?u=james' },
    { id: '4', name: 'Kasey', avatar: 'https://i.pravatar.cc/150?u=kasey' },
  ];

  const chatList = [
    { id: 1, name: 'Adison Lubin', lastMsg: 'Do you want to grab coffee this weekend?', time: 'Just Now', avatar: 'https://i.pravatar.cc/150?u=adison', unread: true },
    { id: 2, name: 'James Vetrovs', lastMsg: 'Let me know if you need anything', time: '3:24 pm', avatar: 'https://i.pravatar.cc/150?u=james', isTyping: true },
    { id: 3, name: 'Ashlynn Mango', lastMsg: "I'll be a little late, hope that's okay", time: 'Yesterday', avatar: 'https://i.pravatar.cc/150?u=ashlynn' },
    { id: 4, name: 'Tatiana Vaccaro', lastMsg: 'Just saw this and thought of you! 😆', time: 'Yesterday', avatar: 'https://i.pravatar.cc/150?u=tatiana' },
    { id: 5, name: 'Nolan Siphron', lastMsg: 'Hey, are you free later?', time: 'Sep 12', avatar: 'https://i.pravatar.cc/150?u=nolan' },
    { id: 6, name: 'Mira Franci', lastMsg: 'Sure, link?', time: 'Sep 8', avatar: 'https://i.pravatar.cc/150?u=mira' },
  ];

  if (selectedChat) {
    return (
      <div className="min-h-screen bg-[#121214] flex flex-col animate-in slide-in-from-right duration-300 pb-20">
        {/* Chat Header */}
        <div className="px-6 py-8 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => setSelectedChat(null)} className="text-zinc-400 hover:text-white transition-colors">
              <ArrowLeft size={24} />
            </button>
            <div className="flex items-center gap-3">
              <img src={selectedChat.avatar} className="w-10 h-10 rounded-full object-cover border border-white/10" alt="" />
              <div>
                <h3 className="text-lg font-bold text-white">{selectedChat.name}</h3>
                <span className="text-[10px] text-zinc-500 font-medium">Online</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button className="p-2 bg-zinc-800/50 rounded-full text-zinc-400 hover:bg-zinc-800 transition-colors">
              <Phone size={20} />
            </button>
            <button className="p-2 bg-zinc-800/50 rounded-full text-zinc-400 hover:bg-zinc-800 transition-colors">
              <Info size={20} />
            </button>
          </div>
        </div>

        {/* Conversation Area */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto px-6 space-y-6 py-4 no-scrollbar">
          <div className="flex justify-center">
            <span className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest bg-zinc-900/50 px-3 py-1 rounded-full">Today</span>
          </div>

          <div className="space-y-4">
            {messages.map((m) => (
              <MessageBubble 
                key={m.id}
                text={m.text} 
                time={m.time} 
                isSender={m.isSender} 
              />
            ))}
            
            {isTyping && (
              <div className="flex flex-col items-start animate-pulse">
                <div className="bg-[#1C1C1E]/60 px-4 py-3 rounded-2xl rounded-tl-none border border-white/5">
                  <div className="flex gap-1">
                    <div className="w-1 h-1 bg-blue-400 rounded-full"></div>
                    <div className="w-1 h-1 bg-blue-400 rounded-full"></div>
                    <div className="w-1 h-1 bg-blue-400 rounded-full"></div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Chat Input */}
        <div className="p-6">
          <form 
            onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }}
            className="bg-[#1C1C1E] rounded-full p-2 flex items-center gap-2 border border-white/5 focus-within:border-blue-500/30 transition-colors"
          >
            <button type="button" className="p-3 bg-zinc-800 rounded-full text-zinc-400 hover:text-white transition-colors">
              <Plus size={20} />
            </button>
            <input 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Type a message..." 
              className="flex-1 bg-transparent border-none outline-none text-sm px-2 text-white placeholder:text-zinc-600"
            />
            <button type="submit" disabled={!inputText.trim()} className="p-3 text-blue-500 disabled:opacity-30 disabled:grayscale transition-all hover:scale-110">
              <Send size={20} fill="currentColor" />
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex flex-col animate-in fade-in duration-300 pb-32">
      {/* Search Header */}
      <div className="px-6 pt-8 pb-4">
        <div className="bg-zinc-900/50 rounded-2xl flex items-center px-4 py-3 gap-3 border border-white/5">
          <Search size={18} className="text-zinc-500" />
          <input 
            type="text" 
            placeholder="Search messages..." 
            className="bg-transparent border-none outline-none text-sm w-full placeholder:text-zinc-600 text-white"
          />
        </div>
      </div>

      {/* Hero Title */}
      <div className="px-8 py-6">
        <h2 className="text-4xl font-bold text-white leading-tight">
          Let's Stay<br />Connected
        </h2>
      </div>

      {/* Horizontal Contacts */}
      <div className="px-6 py-4 flex gap-6 overflow-x-auto no-scrollbar">
        {contacts.map((contact) => (
          <div 
            key={contact.id} 
            className="flex flex-col items-center gap-2 flex-shrink-0 cursor-pointer group"
            onClick={() => !contact.isAdd && setSelectedChat(contact)}
          >
            <div className={`w-16 h-16 rounded-full flex items-center justify-center border-2 transition-all duration-300 group-hover:scale-105 ${contact.isAdd ? 'border-dashed border-zinc-700 bg-zinc-900/30 hover:bg-zinc-800' : 'border-zinc-800 p-0.5 group-hover:border-blue-500/50'}`}>
              {contact.isAdd ? (
                <Plus size={24} className="text-zinc-500" />
              ) : (
                <img src={contact.avatar} className="w-full h-full rounded-full object-cover" alt="" />
              )}
            </div>
            <span className="text-[11px] font-medium text-zinc-400 group-hover:text-white transition-colors">{contact.name}</span>
          </div>
        ))}
      </div>

      {/* Chat List Area */}
      <div className="flex-1 bg-[#121214] rounded-t-[3rem] mt-6 px-6 py-8 space-y-6 shadow-2xl">
        {chatList.map((chat) => (
          <div 
            key={chat.id} 
            onClick={() => setSelectedChat(chat)}
            className="flex items-center gap-4 group cursor-pointer active:opacity-70 transition-opacity"
          >
            <div className="relative">
              <img src={chat.avatar} alt={chat.name} className="w-14 h-14 rounded-full object-cover border border-white/5" />
              {chat.unread && (
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-blue-500 rounded-full border-2 border-[#121214] shadow-lg shadow-blue-500/30" />
              )}
            </div>
            <div className="flex-1 border-b border-white/5 pb-4 group-hover:border-white/10 transition-colors">
              <div className="flex justify-between items-center mb-1">
                <span className="font-bold text-base text-white">{chat.name}</span>
                <span className="text-[10px] text-zinc-600 font-bold uppercase">{chat.time}</span>
              </div>
              <div className="flex items-center gap-1">
                <p className={`text-xs ${chat.unread ? 'text-zinc-300 font-semibold' : 'text-zinc-500'} truncate flex-1`}>
                  {chat.lastMsg}
                </p>
                {chat.isTyping && <div className="w-4 h-4 flex items-center gap-0.5">
                  <div className="w-1 h-1 bg-blue-400 rounded-full animate-bounce"></div>
                  <div className="w-1 h-1 bg-blue-400 rounded-full animate-bounce delay-75"></div>
                  <div className="w-1 h-1 bg-blue-400 rounded-full animate-bounce delay-150"></div>
                </div>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const MessageBubble: React.FC<{ text: string; time: string; isSender: boolean }> = ({ text, time, isSender }) => (
  <div className={`flex flex-col ${isSender ? 'items-end' : 'items-start'} animate-in slide-in-from-bottom-2 duration-300`}>
    <div className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm ${
      isSender 
        ? 'bg-[#2C2C2E] text-white rounded-tr-none shadow-lg' 
        : 'bg-[#1C1C1E]/60 text-zinc-300 rounded-tl-none border border-white/5'
    }`}>
      {text}
    </div>
    <span className="text-[9px] text-zinc-600 mt-1 font-bold">{time}</span>
  </div>
);

export default Messages;
