
import React, { useState } from 'react';
import { Search, MapPin, TrendingUp, Music, Layout } from 'lucide-react';

const Explore: React.FC = () => {
  const categories = ['Popular', 'Latest', 'Sports', 'Traveling', 'News', 'Art', 'Fashion'];
  const [activeCat, setActiveCat] = useState('Popular');

  const trendingItems = [
    { id: 1, url: 'https://picsum.photos/seed/exp1/400/600', views: '1.2 M' },
    { id: 2, url: 'https://picsum.photos/seed/exp2/400/600', views: '12 M' },
    { id: 3, url: 'https://picsum.photos/seed/exp3/400/600', views: '6.8 M' },
  ];

  return (
    <div className="px-6 space-y-8 pb-32">
      {/* Header */}
      <div className="flex items-center justify-between pt-4">
        <div>
          <h2 className="text-3xl font-bold">Discover</h2>
          <p className="text-zinc-500 text-sm mt-1">Find your favorit content</p>
        </div>
        <button className="p-3 bg-zinc-900 rounded-2xl">
          <Search size={20} className="text-zinc-400" />
        </button>
      </div>

      {/* Categories Scroll */}
      <div className="flex items-center gap-6 overflow-x-auto no-scrollbar py-2">
        {categories.map((cat) => (
          <button 
            key={cat} 
            onClick={() => setActiveCat(cat)}
            className={`text-sm font-semibold whitespace-nowrap transition-all relative ${activeCat === cat ? 'text-amber-400' : 'text-zinc-500'}`}
          >
            {cat}
            {activeCat === cat && <span className="absolute -bottom-2 left-0 w-6 h-0.5 bg-amber-400 rounded-full" />}
          </button>
        ))}
      </div>

      {/* Hero Grid */}
      <div className="flex gap-4 overflow-x-auto no-scrollbar snap-x">
        {trendingItems.map((item) => (
          <div key={item.id} className="relative w-40 aspect-[9/14] flex-shrink-0 rounded-3xl overflow-hidden snap-center group">
            <img src={item.url} alt="Trending" className="w-full h-full object-cover transition-transform group-hover:scale-110" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-4">
              <span className="text-[10px] font-bold text-zinc-400">{item.views} Views</span>
            </div>
          </div>
        ))}
      </div>

      {/* Recommended Section */}
      <div className="space-y-6">
        <h3 className="font-bold text-lg flex items-center gap-2">
          Recommended For You
        </h3>
        
        <div className="grid grid-cols-1 gap-6">
          <div className="bg-zinc-900/40 rounded-[2.5rem] p-6 border border-white/5 space-y-4">
            <div className="flex items-center gap-3">
               <img src="https://picsum.photos/seed/wh/50/50" className="w-10 h-10 rounded-full" />
               <div className="flex-1">
                 <p className="text-sm font-bold">Whang_yiming.xi <span className="text-[10px] text-zinc-500 ml-2">4 hour ago</span></p>
                 <p className="text-[10px] text-zinc-500">Photographer & Traveller</p>
               </div>
            </div>
            <p className="text-xs text-zinc-400 italic">✨ "Look up, stay grounded." Sometimes all we need is a fresh perspective. #MindsetMatters</p>
            <div className="relative aspect-video rounded-3xl overflow-hidden">
               <img src="https://picsum.photos/seed/whimg/600/400" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Explore;
