
import React, { useState } from 'react';
import { Camera, Image as ImageIcon, Sparkles, X, ChevronRight, Tag } from 'lucide-react';
import { generateCaption } from '../services/gemini';
import { UserNiche } from '../types';

interface CreatePostProps {
  onCancel: () => void;
  niche: UserNiche;
}

const CreatePost: React.FC<CreatePostProps> = ({ onCancel, niche }) => {
  const [step, setStep] = useState<'select' | 'details'>('select');
  const [caption, setCaption] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedImage, setSelectedImage] = useState('https://picsum.photos/seed/preview/800/1000');
  const [activeNiche, setActiveNiche] = useState<UserNiche>(niche);

  const handleGenerateAI = async () => {
    setIsGenerating(true);
    const aiCaption = await generateCaption(`a premium post in the ${activeNiche} niche`);
    setCaption(aiCaption);
    setIsGenerating(false);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-zinc-950 flex flex-col animate-in fade-in zoom-in-95 duration-300">
      <div className="px-6 py-6 flex items-center justify-between">
        <button onClick={onCancel} className="p-2 bg-zinc-900 rounded-xl"><X size={24} /></button>
        <h2 className="text-lg font-black uppercase tracking-tighter">New Entry</h2>
        <button onClick={() => step === 'select' ? setStep('details') : onCancel()} className="text-blue-500 font-black uppercase tracking-widest text-xs">
          {step === 'select' ? 'Next' : 'Share'}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-6 space-y-8 pb-10">
        {step === 'select' ? (
          <div className="space-y-6">
            <div className="aspect-[4/5] rounded-[2.5rem] overflow-hidden bg-zinc-900 relative border border-white/5 shadow-2xl">
              <img src={selectedImage} className="w-full h-full object-cover" />
              <button className="absolute bottom-6 right-6 p-4 bg-black/50 backdrop-blur-xl rounded-2xl border border-white/10 text-blue-400">
                <Camera size={24} />
              </button>
            </div>
            
            <div className="grid grid-cols-4 gap-2">
              {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
                <div key={i} className="aspect-square rounded-xl bg-zinc-900 overflow-hidden cursor-pointer" onClick={() => setSelectedImage(`https://picsum.photos/seed/sel${i}/400/500`)}>
                  <img src={`https://picsum.photos/seed/sel${i}/100/100`} className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            <div className="flex gap-4">
              <img src={selectedImage} className="w-24 h-32 rounded-2xl object-cover border border-white/5" />
              <div className="flex-1 relative">
                <textarea 
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  placeholder="Share your niche expertise..." 
                  className="w-full h-full bg-transparent border-none outline-none resize-none text-sm placeholder:text-zinc-700 font-medium"
                />
                <button 
                  onClick={handleGenerateAI}
                  disabled={isGenerating}
                  className="absolute bottom-0 right-0 p-2 bg-blue-500/10 text-blue-400 rounded-lg flex items-center gap-1.5 text-[9px] font-black uppercase tracking-widest"
                >
                  <Sparkles size={12} />
                  {isGenerating ? 'Synthesizing...' : 'AI Enhance'}
                </button>
              </div>
            </div>

            <div className="space-y-3">
               <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Niche Category</label>
               <div className="flex flex-wrap gap-2">
                 {['General', 'Fitness', 'Business', 'Developer', 'Creator', 'Artist'].map(n => (
                   <button 
                    key={n}
                    onClick={() => setActiveNiche(n as UserNiche)}
                    className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase border transition-all ${activeNiche === n ? 'bg-blue-500 text-white border-blue-500' : 'bg-white/5 text-zinc-500 border-white/10'}`}
                   >
                     {n}
                   </button>
                 ))}
               </div>
            </div>

            <div className="space-y-4">
              <ActionItem label="Target Audience" icon={<Tag size={18} />} />
              <ActionItem label="Advanced Rendering" icon={<ChevronRight size={18} />} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const ActionItem: React.FC<{ label: string, icon?: React.ReactNode }> = ({ label, icon }) => (
  <button className="w-full flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all">
    <span className="text-sm font-bold text-zinc-300">{label}</span>
    <div className="text-zinc-600">{icon}</div>
  </button>
);

export default CreatePost;
