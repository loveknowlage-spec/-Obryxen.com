
import React, { useState } from 'react';
import { Heart, MessageCircle, Share2, MoreVertical, Music, ChevronLeft, Bookmark } from 'lucide-react';

interface ReelsProps {
  onBack?: () => void;
}

const Reels: React.FC<ReelsProps> = ({ onBack }) => {
  const [reels, setReels] = useState([
    {
      id: 1,
      user: 'alexa_prime',
      caption: 'The golden hour in Switzerland is just built different. 🏔️✨',
      music: 'Original Audio - Alexa Prime',
      likes: 1400000,
      comments: 12000,
      bg: 'https://picsum.photos/seed/reel1/1080/1920',
      isLiked: false,
      isSaved: false
    }
  ]);

  const toggleLike = (id: number) => {
    setReels(prev => prev.map(reel => {
      if (reel.id === id) {
        const isLiked = !reel.isLiked;
        return {
          ...reel,
          isLiked,
          likes: isLiked ? reel.likes + 1 : reel.likes - 1
        };
      }
      return reel;
    }));
  };

  const toggleSave = (id: number) => {
    setReels(prev => prev.map(reel => {
      if (reel.id === id) return { ...reel, isSaved: !reel.isSaved };
      return reel;
    }));
  };

  const handleComment = (reel: any) => {
    const comment = prompt(`Add a comment to @${reel.user}'s reel:`);
    if (comment) {
      alert(`Comment added: ${comment}`);
      setReels(prev => prev.map(r => r.id === reel.id ? { ...r, comments: r.comments + 1 } : r));
    }
  };

  const formatStats = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  return (
    <div className="fixed inset-0 bg-black z-10 flex flex-col">
      {reels.map(reel => (
        <div key={reel.id} className="relative flex-1">
          {/* Background Media */}
          <div className="absolute inset-0">
            <img src={reel.bg} className="w-full h-full object-cover opacity-80" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40"></div>
          </div>

          {/* Top Header */}
          <div className="absolute top-10 left-6 right-6 flex items-center justify-between z-20">
            <div className="flex items-center gap-4">
              {onBack && (
                <button onClick={onBack} className="p-2 bg-black/20 backdrop-blur-md rounded-full text-white">
                  <ChevronLeft size={24} />
                </button>
              )}
              <h2 className="text-2xl font-bold text-white">Reels</h2>
            </div>
            <button className="text-white"><MoreVertical /></button>
          </div>

          {/* Interaction Bar */}
          <div className="absolute right-6 bottom-32 flex flex-col items-center gap-6 z-20">
            <div className="flex flex-col items-center gap-1 group">
               <button 
                 onClick={() => toggleLike(reel.id)}
                 className={`bg-zinc-900/40 backdrop-blur-xl p-3 rounded-2xl border border-white/10 active:scale-90 transition-transform ${reel.isLiked ? 'text-rose-500' : 'text-white'}`}
               >
                 <Heart size={28} fill={reel.isLiked ? "currentColor" : "none"} />
               </button>
               <span className="text-[10px] font-bold text-white">{formatStats(reel.likes)}</span>
            </div>
            <div className="flex flex-col items-center gap-1">
               <button 
                 onClick={() => handleComment(reel)}
                 className="bg-zinc-900/40 backdrop-blur-xl p-3 rounded-2xl border border-white/10 active:scale-90 transition-transform text-white"
               >
                 <MessageCircle size={28} />
               </button>
               <span className="text-[10px] font-bold text-white">{formatStats(reel.comments)}</span>
            </div>
            <div className="flex flex-col items-center gap-1">
               <button 
                onClick={() => toggleSave(reel.id)}
                className={`bg-zinc-900/40 backdrop-blur-xl p-3 rounded-2xl border border-white/10 active:scale-90 transition-transform ${reel.isSaved ? 'text-blue-500' : 'text-white'}`}
               >
                 <Bookmark size={28} fill={reel.isSaved ? "currentColor" : "none"} />
               </button>
            </div>
            <div className="bg-zinc-900/40 backdrop-blur-xl p-3 rounded-2xl border border-white/10 text-white">
               <Share2 size={28} />
            </div>
          </div>

          {/* Info Area */}
          <div className="absolute left-6 bottom-32 right-20 space-y-4 z-20">
             <div className="flex items-center gap-3">
               <img src="https://picsum.photos/seed/ra/50/50" className="w-10 h-10 rounded-full border-2 border-amber-500" />
               <span className="font-bold text-white">@{reel.user}</span>
               <button className="px-4 py-1.5 bg-white/10 backdrop-blur-xl rounded-full text-xs font-bold border border-white/20 text-white">Follow</button>
             </div>
             <p className="text-sm line-clamp-2 leading-relaxed text-white">{reel.caption}</p>
             <div className="flex items-center gap-2 text-xs text-zinc-300">
                <Music size={14} />
                <span className="marquee">{reel.music}</span>
             </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Reels;
