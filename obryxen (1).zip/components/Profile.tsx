
import React, { useState, useRef } from 'react';
import { 
  CheckCircle2, 
  Image as ImageIcon, 
  PlayCircle, 
  Bookmark,
  Briefcase,
  Globe,
  Rocket,
  Edit3,
  X,
  Camera,
  Dumbbell,
  Terminal,
  Palette,
  Mic2,
  Settings,
  Trash2,
  Upload,
  UserX,
  Plus
} from 'lucide-react';
import { auth } from '../firebase';
import { updateProfile } from 'firebase/auth';
import { UserNiche } from '../types';

interface ProfileProps {
  niche: UserNiche;
  onUpdateNiche?: () => void;
}

const Profile: React.FC<ProfileProps> = ({ niche, onUpdateNiche }) => {
  const [activeTab, setActiveTab] = useState('Photo');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [displayName, setDisplayName] = useState(auth.currentUser?.displayName || 'bncv');
  const [bio, setBio] = useState('Building the future of digital social systems.');
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [stats, setStats] = useState([
    { label: 'POST', value: '2.6k' },
    { label: 'FOLLOWER', value: '1.2M' },
    { label: 'FOLLOWING', value: '868' },
    { label: 'NAS SCORE', value: '98%' },
  ]);

  const [content, setContent] = useState([
    { id: 1, views: '1.2 M', img: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?w=400&h=600&fit=crop', caption: 'Deep in thought' },
    { id: 2, views: '12 M', img: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=400&h=600&fit=crop', caption: 'Nature vibe' },
    { id: 3, views: '6.8 M', img: 'https://images.unsplash.com/photo-1436491865332-7a61a109c0f3?w=400&h=600&fit=crop', caption: 'Sky high' },
  ]);

  const nicheConfig = {
    Fitness: { icon: <Dumbbell size={16} className="text-rose-400" />, accent: 'text-rose-400', bg: 'bg-rose-500/10' },
    Developer: { icon: <Terminal size={16} className="text-emerald-400" />, accent: 'text-emerald-400', bg: 'bg-emerald-500/10' },
    Business: { icon: <Briefcase size={16} className="text-amber-400" />, accent: 'text-amber-400', bg: 'bg-amber-500/10' },
    Creator: { icon: <Mic2 size={16} className="text-purple-400" />, accent: 'text-purple-400', bg: 'bg-purple-500/10' },
    Artist: { icon: <Palette size={16} className="text-pink-400" />, accent: 'text-pink-400', bg: 'bg-pink-500/10' },
    General: { icon: <Rocket size={16} className="text-blue-400" />, accent: 'text-blue-400', bg: 'bg-blue-500/10' }
  }[niche];

  const handleUpdateProfile = async () => {
    if (!auth.currentUser) return;
    setLoading(true);
    try {
      await updateProfile(auth.currentUser, { displayName });
      setIsEditModalOpen(false);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleRemovePhoto = async () => {
    if (!auth.currentUser) return;
    if (!confirm("Are you sure you want to remove your profile picture?")) return;
    setLoading(true);
    try {
      await updateProfile(auth.currentUser, { photoURL: "" });
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleUploadPhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && auth.currentUser) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        setLoading(true);
        try {
          await updateProfile(auth.currentUser!, { photoURL: reader.result as string });
        } catch (error) {
          console.error(error);
        } finally {
          setLoading(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const deletePost = (id: number) => {
    if (confirm("Delete post forever?")) {
      setContent(content.filter(item => item.id !== id));
    }
  };

  const editPost = (id: number) => {
    const post = content.find(item => item.id === id);
    const newCaption = prompt("New caption:", post?.caption);
    if (newCaption !== null) {
      setContent(content.map(item => item.id === id ? { ...item, caption: newCaption } : item));
    }
  };

  return (
    <div className="pb-40 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleUploadPhoto} />
      
      <div className="px-6 pt-12 pb-8 flex items-start gap-6">
        {/* Profile Image with Add/Remove Option */}
        <div className="relative flex-shrink-0 group">
          <div className="absolute inset-0 bg-blue-500/10 blur-2xl rounded-full scale-125"></div>
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="w-32 h-32 rounded-[2.5rem] overflow-hidden bg-zinc-900 p-1 relative z-10 shadow-2xl border border-white/10 cursor-pointer hover:scale-[1.02] transition-transform"
          >
            {auth.currentUser?.photoURL ? (
              <img src={auth.currentUser.photoURL} className="w-full h-full object-cover rounded-[2.3rem]" alt="Profile" />
            ) : (
              <div className="w-full h-full rounded-[2.3rem] bg-zinc-800 flex items-center justify-center text-zinc-500">
                <Plus size={32} />
              </div>
            )}
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-[2.3rem]">
              <Camera size={24} className="text-white" />
            </div>
          </div>
          
          {auth.currentUser?.photoURL && (
            <button 
              onClick={(e) => { e.stopPropagation(); handleRemovePhoto(); }}
              className="absolute -top-1 -right-1 z-20 p-1.5 bg-zinc-900 border border-white/10 rounded-full text-rose-500 shadow-xl hover:bg-rose-500 hover:text-white transition-all"
              title="Remove Profile Picture"
            >
              <Trash2 size={12} />
            </button>
          )}
        </div>
        
        <div className="flex-1 space-y-4 pt-2">
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-black tracking-tight">{displayName}</h1>
            <CheckCircle2 size={20} className="text-blue-500 fill-blue-500/10" />
          </div>
          
          <div className="flex items-center gap-3">
             <span className="text-[10px] font-black uppercase tracking-tighter px-3 py-1 rounded-lg bg-zinc-800 text-zinc-400">
               {niche === 'General' ? 'GENERAL' : niche.toUpperCase()}
             </span>
             <span className="text-xs text-zinc-600 font-bold lowercase">@{auth.currentUser?.email?.split('@')[0] || 'unrevealedbd77'}</span>
          </div>
          
          <div className="flex gap-2">
            <button 
              onClick={() => setIsEditModalOpen(true)} 
              className="flex-1 py-3 bg-zinc-900/50 hover:bg-zinc-900 rounded-full text-[11px] font-black uppercase tracking-widest flex items-center justify-center gap-2 border border-white/5 transition-all"
            >
              <Edit3 size={14} />
              CUSTOMIZE
            </button>
            <button onClick={onUpdateNiche} className="p-3 bg-zinc-900/50 hover:bg-zinc-900 rounded-2xl border border-white/5 transition-all">
              <Settings size={18} className="text-zinc-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Stats - Boxed as in screenshot */}
      <div className="px-6 mb-8 grid grid-cols-4 gap-3">
        {stats.map((stat) => (
          <div key={stat.label} className="text-center bg-zinc-900/40 border border-white/5 py-5 rounded-[1.5rem] shadow-sm">
            <p className="text-xl font-black text-white">{stat.value}</p>
            <p className="text-[9px] font-black text-zinc-600 uppercase tracking-widest mt-0.5">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="px-10 mb-10 space-y-3">
        <p className="text-sm font-bold text-zinc-300 leading-relaxed">{bio}</p>
        <div className="flex items-center gap-3 text-[13px] font-bold text-cyan-400">
          <Globe size={16} />
          <span>obryxen.space/{auth.currentUser?.email?.split('@')[0] || 'unrevealedbd77'}</span>
        </div>
      </div>

      <div className="flex items-center justify-around px-10 mb-8 border-b border-white/5 pb-4">
        <TabItem icon={<ImageIcon size={22} />} label="GRID" active={activeTab === 'Photo'} onClick={() => setActiveTab('Photo')} />
        <TabItem icon={<PlayCircle size={22} />} label="REELS" active={activeTab === 'Reels'} onClick={() => setActiveTab('Reels')} />
        <TabItem icon={<Bookmark size={22} />} label="SAVED" active={activeTab === 'Marked'} onClick={() => setActiveTab('Marked')} />
      </div>

      <div className="px-4 grid grid-cols-3 gap-3">
        {content.map((item) => (
          <div key={item.id} className="relative aspect-[9/14] rounded-[1.8rem] overflow-hidden group border border-white/5 shadow-lg bg-zinc-900">
            <img src={item.img} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" alt="" />
            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-4">
               <button onClick={() => editPost(item.id)} className="p-3 bg-white text-black rounded-full hover:scale-110 transition-transform"><Edit3 size={18} /></button>
               <button onClick={() => deletePost(item.id)} className="p-3 bg-rose-600 text-white rounded-full hover:scale-110 transition-transform"><Trash2 size={18} /></button>
            </div>
          </div>
        ))}
        {/* Placeholder for empty space in grid */}
        <div className="aspect-[9/14] rounded-[1.8rem] bg-zinc-900/40 border border-dashed border-white/5 flex items-center justify-center">
           <Plus size={24} className="text-zinc-800" />
        </div>
      </div>

      {isEditModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-xl" onClick={() => setIsEditModalOpen(false)}></div>
          <div className="glass-card w-full max-w-sm rounded-[3rem] p-8 relative z-10 border border-white/10 shadow-2xl">
            <div className="flex justify-between items-center mb-8">
               <h2 className="text-2xl font-black uppercase tracking-tighter">Edit Identity</h2>
               <button onClick={() => setIsEditModalOpen(false)}><X size={24} /></button>
            </div>
            <div className="space-y-6">
              <div className="flex flex-col items-center gap-4">
                <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-white/10 p-1 bg-zinc-900">
                  {auth.currentUser?.photoURL ? (
                    <img src={auth.currentUser.photoURL} className="w-full h-full rounded-full object-cover" alt="" />
                  ) : (
                    <div className="w-full h-full rounded-full bg-zinc-800 flex items-center justify-center"><UserX size={24} className="text-zinc-700" /></div>
                  )}
                </div>
                <div className="flex flex-col gap-2 w-full">
                  <button onClick={() => fileInputRef.current?.click()} className="w-full py-3 bg-blue-500/10 text-blue-400 rounded-xl text-[11px] font-black uppercase flex items-center justify-center gap-2 tracking-widest"><Upload size={14}/> UPLOAD PICTURE</button>
                  {auth.currentUser?.photoURL && (
                    <button onClick={handleRemovePhoto} className="w-full py-3 bg-rose-500/10 text-rose-500 rounded-xl text-[11px] font-black uppercase flex items-center justify-center gap-2 tracking-widest"><UserX size={14}/> REMOVE PICTURE</button>
                  )}
                </div>
              </div>
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-600 uppercase ml-1 tracking-widest">DISPLAY NAME</label>
                  <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="w-full bg-white/5 border border-white/5 rounded-2xl px-6 py-4 text-sm outline-none font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-600 uppercase ml-1 tracking-widest">BIOGRAPHY</label>
                  <textarea value={bio} onChange={(e) => setBio(e.target.value)} className="w-full bg-white/5 border border-white/5 rounded-2xl px-6 py-4 text-sm outline-none h-24 resize-none font-medium" />
                </div>
              </div>
              <button onClick={handleUpdateProfile} disabled={loading} className="w-full py-5 bg-white text-black rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl active:scale-[0.98] transition-transform">{loading ? 'PROCESSING...' : 'SYNC IDENTITY'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const TabItem: React.FC<{ icon: React.ReactNode; label: string; active: boolean; onClick: () => void; }> = ({ icon, label, active, onClick }) => (
  <button onClick={onClick} className={`flex flex-col items-center gap-2 transition-all ${active ? 'text-white scale-110' : 'text-zinc-600'}`}>
    {icon}
    <span className="text-[10px] font-black uppercase tracking-widest">{label}</span>
    {active && <div className="w-1 h-1 bg-white rounded-full"></div>}
  </button>
);

export default Profile;
