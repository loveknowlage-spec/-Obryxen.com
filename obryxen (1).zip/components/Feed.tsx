
import React, { useState } from 'react';
import { Heart, MessageCircle, Bookmark, MoreHorizontal, CheckCircle2, Image as ImageIcon, Film, MapPin, Sparkles, UserPlus, UserCheck } from 'lucide-react';
import { auth } from '../firebase';
import { UserNiche, Post } from '../types';

interface FeedProps {
  onOpenCreate?: () => void;
  activeNiche: UserNiche;
}

const Feed: React.FC<FeedProps> = ({ onOpenCreate, activeNiche }) => {
  const currentUser = auth.currentUser;
  const [feedType, setFeedType] = useState<'following' | 'explore'>('following');
  
  // Simulation of Niche Affinity Ranking
  const [posts, setPosts] = useState<Post[]>([
    {
      id: '1',
      userId: 'p1',
      username: 'pokazka.pro',
      userAvatar: 'https://i.pravatar.cc/150?u=pokazka',
      url: 'https://images.unsplash.com/photo-1588392382834-a891154bca4d?q=80&w=600&h=400&fit=crop',
      caption: 'The NAS algorithm successfully prioritized this high-fidelity Bromo landscape based on my current interests.',
      likes: 19800,
      comments: 3000,
      timestamp: 'JUST NOW',
      isVerified: true,
      nicheTag: 'Creator',
      type: 'image',
      isLiked: false,
      isSaved: false
    },
    {
      id: '2',
      userId: 'p2',
      username: 'aesthetic.vibe',
      userAvatar: 'https://i.pravatar.cc/150?u=aest',
      url: 'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?q=80&w=600&h=400&fit=crop',
      caption: 'Found a new architecture pattern today. This is essential for the Niche-Driven Shell approach.',
      likes: 12400,
      comments: 840,
      timestamp: '15m AGO',
      isVerified: false,
      nicheTag: 'Developer',
      type: 'image',
      isLiked: false,
      isSaved: false
    }
  ]);

  const [following, setFollowing] = useState<Set<string>>(new Set());

  const toggleLike = (postId: string) => {
    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        const isLiked = !post.isLiked;
        return {
          ...post,
          isLiked,
          likes: isLiked ? post.likes + 1 : post.likes - 1
        };
      }
      return post;
    }));
  };

  const toggleSave = (postId: string) => {
    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        return { ...post, isSaved: !post.isSaved };
      }
      return post;
    }));
  };

  const toggleFollow = (userId: string) => {
    setFollowing(prev => {
      const next = new Set(prev);
      if (next.has(userId)) next.delete(userId);
      else next.add(userId);
      return next;
    });
  };

  const handleComment = (post: Post) => {
    const comment = prompt(`Write a comment for @${post.username}:`);
    if (comment) {
      alert(`Comment sent: ${comment}`);
      setPosts(prev => prev.map(p => p.id === post.id ? { ...p, comments: p.comments + 1 } : p));
    }
  };

  // Logic: Prioritize the user's active niche in the explore feed
  const sortedPosts = [...posts].sort((a, b) => {
    if (a.nicheTag === activeNiche) return -1;
    if (b.nicheTag === activeNiche) return 1;
    return 0;
  });

  const formatLikes = (num: number) => {
    if (num >= 1000) return (num / 1000).toFixed(1) + 'k';
    return num.toString();
  };

  return (
    <div className="space-y-6 px-4 pt-4 pb-32">
      {/* Personalized Feed Toggle */}
      <div className="flex items-center justify-between mb-4 px-2">
        <div className="glass-card rounded-full p-1 flex gap-1">
          <button 
            onClick={() => setFeedType('following')}
            className={`px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${feedType === 'following' ? 'bg-white text-black shadow-lg' : 'text-zinc-500'}`}
          >
            My Feed
          </button>
          <button 
            onClick={() => setFeedType('explore')}
            className={`px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${feedType === 'explore' ? 'bg-white text-black shadow-lg' : 'text-zinc-500'}`}
          >
            Niche-OS
          </button>
        </div>
        <div className="flex items-center gap-2 glass-card px-4 py-2 rounded-full border border-blue-500/20">
           <Sparkles size={12} className="text-blue-400" />
           <span className="text-[10px] font-black uppercase tracking-tighter text-blue-400">{activeNiche} Mode</span>
        </div>
      </div>

      {/* Create Entry Point */}
      <div 
        onClick={onOpenCreate}
        className="glass-card rounded-[2.5rem] p-6 cursor-pointer hover:bg-white/[0.05] transition-all group border border-white/5 shadow-xl"
      >
        <div className="flex gap-4 items-center">
          <img 
            src={currentUser?.photoURL || `https://i.pravatar.cc/150?u=${currentUser?.uid}`} 
            className="w-12 h-12 rounded-full border border-white/10"
            alt="User"
          />
          <div className="flex-1 flex flex-col justify-center">
            <span className="text-zinc-500 text-sm font-medium">
              What's the latest in {activeNiche}, {currentUser?.displayName?.split(' ')[0]}?
            </span>
          </div>
          <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-zinc-600 group-hover:text-blue-400 transition-colors">
            <ImageIcon size={20} />
          </div>
        </div>
      </div>

      {/* Feed List */}
      {sortedPosts.map((post) => (
        <div key={post.id} className="glass-card rounded-[3rem] overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6 duration-500">
          <div className="flex items-center justify-between px-7 pt-7 pb-5">
             <div className="flex items-center gap-4">
              <img src={post.userAvatar} className="w-10 h-10 rounded-full object-cover border border-white/10" />
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-sm text-white">{post.username}</span>
                  {post.isVerified && <CheckCircle2 size={14} className="text-blue-500" />}
                  <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-full bg-white/5 border border-white/10 ${post.nicheTag === activeNiche ? 'text-blue-400' : 'text-zinc-600'}`}>
                    {post.nicheTag}
                  </span>
                </div>
                <span className="text-[9px] text-zinc-600 font-black tracking-widest uppercase">{post.timestamp}</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => toggleFollow(post.userId)}
                className={`p-2 rounded-xl transition-all ${following.has(post.userId) ? 'bg-white/5 text-blue-400' : 'bg-blue-500 text-white'}`}
              >
                {following.has(post.userId) ? <UserCheck size={16} /> : <UserPlus size={16} />}
              </button>
              <button className="p-2 text-zinc-500"><MoreHorizontal size={20} /></button>
            </div>
          </div>

          <div className="px-5">
            <div className="aspect-[4/3] rounded-[2.5rem] overflow-hidden bg-zinc-900 border border-white/5 relative group">
              <img src={post.url} className="w-full h-full object-cover opacity-90 transition-transform duration-1000 group-hover:scale-110" />
            </div>
          </div>

          <div className="px-8 py-7">
            <p className="text-zinc-400 text-sm leading-relaxed font-medium">
              <span className="font-bold text-white mr-2">{post.username}</span>
              {post.caption}
            </p>
            
            <div className="flex items-center justify-between mt-6 pt-6 border-t border-white/5">
              <div className="flex items-center gap-6">
                <button 
                  onClick={() => toggleLike(post.id)}
                  className="flex items-center gap-2 group transition-all active:scale-110"
                >
                  <Heart size={20} className={post.isLiked ? "text-rose-500 fill-rose-500" : "text-zinc-500"} />
                  <span className={`text-xs font-black ${post.isLiked ? "text-rose-500" : "text-zinc-600"}`}>
                    {formatLikes(post.likes)}
                  </span>
                </button>
                <button 
                  onClick={() => handleComment(post)}
                  className="flex items-center gap-2 group transition-all active:scale-110"
                >
                  <MessageCircle size={20} className="text-zinc-500 group-hover:text-white" />
                  <span className="text-xs font-black text-zinc-600 group-hover:text-zinc-400">
                    {formatLikes(post.comments)}
                  </span>
                </button>
              </div>
              <button 
                onClick={() => toggleSave(post.id)}
                className={`transition-all active:scale-110 ${post.isSaved ? "text-blue-500" : "text-zinc-500"}`}
              >
                <Bookmark size={20} fill={post.isSaved ? "currentColor" : "none"} />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Feed;
